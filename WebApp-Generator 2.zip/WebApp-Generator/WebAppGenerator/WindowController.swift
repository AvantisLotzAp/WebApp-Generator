//
//  WindowController.swift
//  WebAppGenerator
//
//  Created by LIPL-227 on 31/03/22.
//

import Cocoa

class WindowController: NSWindowController {

    convenience  init() {
        self.init(windowNibName  : "WindowController")
    }
    
    override func windowDidLoad() {
        super.windowDidLoad()
        contentViewController = WebLoadNSViewController()
    
        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }

}
