//
//  AppDelegate.swift
//  WebAppGenerator
//
//  Created by LIPL-227 on 16/02/22.
//

import Cocoa

@main
class AppDelegate: NSObject, NSApplicationDelegate {

    let mainWindowController = WindowController()
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
        mainWindowController.showWindow(nil)
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }

    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        return true
    }

   
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if !flag{
            mainWindowController.window?.makeKeyAndOrderFront(nil)
        }
        return true
    }
    

}

